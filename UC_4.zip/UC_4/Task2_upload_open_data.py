import requests
import boto3

def upload_to_s3():
    aws_access_key_id = 'AKIATOQCU5XVPJWHQTN4'
    aws_secret_access_key = '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'
    aws_region = 'eu-west-1'

    s3 = boto3.client('s3', aws_access_key_id=aws_access_key_id, aws_secret_access_key=aws_secret_access_key, region_name=aws_region)


    download_url = "https://s3.ap-southeast-1.amazonaws.com/table-downloads-ingest.data.gov.sg/d_832d446094a3f15f813c6755cdc0650f.csv?AWSAccessKeyId=ASIAU7LWPY2WFAHJTR4X&Expires=1698785425&Signature=QlDEFSBWj1H%2BghS8Wdc8Z7TQJRM%3D&X-Amzn-Trace-Id=Root%3D1-65415a80-40c14e933400de4370fbe661%3BParent%3D270b149b2802ea7d%3BSampled%3D0%3BLineage%3D7237e2ef%3A0&response-content-disposition=attachment%3B%20filename%3D%22NumberofUnemployedCitizensQuarterly.csv%22&x-amz-security-token=IQoJb3JpZ2luX2VjEMz%2F%2F%2F%2F%2F%2F%2F%2F%2F%2FwEaDmFwLXNvdXRoZWFzdC0xIkcwRQIgHW4DadvYbY9nx1rhjqbCEyoRMQRJ5eMlEXqrunQyXJwCIQCtrgrnPWuhX5zg7tMpCxZ6Rmw6Jj3q7MDxgWtygeYwCSrDAwj1%2F%2F%2F%2F%2F%2F%2F%2F%2F%2F8BEAQaDDM0MjIzNTI2ODc4MCIMKaVpKHIIDnH4rH9CKpcD94a6u5ejYIu037R8WyAJtJvP6ZkKvjF2ABN%2FWjBt9%2BvZRJhovPUA9S7psPZMDw3eFaAZcMAuo%2FeCSIXbCk%2BECuQmXjsm9ic8F4V1xwygYhqBvHGW7dDrQX9KAV0LvcEBjlXJP0OzrRwOnbaryZ9zw%2BfNUupQq1HcjI9UhS4fYsvEIzRR0cGKC7%2F4B2dwgppfmW%2Fyb%2BlUntoa8kFxswS5MYMTxcRE6Zeyt%2F89YlJb5iF%2BTDVOJwEDG54%2Bej8Tefl25fFIujs7jRQllrRrOOIPgYOAnY2XaY0FlR3upoyyvT3Fe0PPs79EwDKjGPRZBkB9Cpvb8YXE0v3rixLeNzFFUTpfoYNa4ppeyUE9e4gRAaAIXY%2Bukhrg0hkbjCN0DmYSRZLzRzOpnTEpJJT4bXLT7i2aDi0NPrxl%2F2AuwYCWcG0dS6gIIRkWjnc%2FvZOV4C1oLONBm38jDA4zrfenaHJebe0h%2BC5P6QyRfpf7I2l6WjHTucItWaQ%2FTg3N6keTdt0fcsaU0ojkT6PGYy30lO%2Fg0pga62tAYWswnbKFqgY6ngGfUX2l04ZNnXYcNxdH%2B6HEhva%2B6p13iGJZvMPkjE3C%2BDCy%2BXUam2Mx6SsgLHolk9gPoYwnrlW8mg74wMdWWVmweG8Tp%2FBlOkzdo9b0gZjWUq1b0fDpTeHMTsLfnjeFVRyrzzdmQZRaiql%2BuzQhZwRUwHC1NG6s%2BDLPO3dBlCC4R1ZJOo1ZnkQv2tNnOu9HiT%2BjUMuj5dnO8vhpxD509w%3D%3D"

    save_path = "downloaded_dataset.csv"

    # Send an HTTP GET request to download the file
    response = requests.get(download_url)

    # Check if the request was successful (status code 200)
    if response.status_code == 200:
        with open(save_path, "wb") as f:
            f.write(response.content)
        print(f"Dataset downloaded and saved as {save_path}")
    else:
        print(f"Failed to download the dataset. Status code: {response.status_code}")

    s3_bucket_name = 'uc3'
    s3_object_key = 'Open data code/file.csv'

    s3.upload_file(save_path, s3_bucket_name, s3_object_key)

upload_to_s3()    